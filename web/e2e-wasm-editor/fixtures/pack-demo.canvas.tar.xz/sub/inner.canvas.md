<!-- meshfox:canvas -->
# Inner canvas
<!-- meshfox:node id="root" -->

A canvas that the pack carried along.
