<!-- meshfox:canvas -->
# Pack demo
<!-- meshfox:node id="root" -->

The root of a packed canvas.

![dot](img/dot.png)

## Notes
<!-- meshfox:node id="notes" type="include" -->

[notes](./notes.md)

## Inner
<!-- meshfox:node id="inner" type="file" -->

[inner](./sub/inner.canvas.md)
