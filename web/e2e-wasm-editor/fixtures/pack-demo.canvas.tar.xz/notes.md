# Notes from the pack

This text was included from notes.md.
