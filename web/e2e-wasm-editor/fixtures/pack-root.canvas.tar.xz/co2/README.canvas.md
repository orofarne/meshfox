<!-- meshfox:canvas -->
# Sensor in a subdirectory
<!-- meshfox:node id="root" -->

This canvas reads its sibling directory.

![dot](../docs/dot.png)

## Notes
<!-- meshfox:node id="notes" type="include" -->

[notes](../docs/notes.md)
