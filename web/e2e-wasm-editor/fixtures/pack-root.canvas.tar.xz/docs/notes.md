# Notes from the docs directory

Included through a ../ path.
